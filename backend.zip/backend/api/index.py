from backend.main import app  # Adjust import based on structure

# Vercel uses `app` as entry point
# This file will be served as the function handler
